package com.example.homeautsystem;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Templightifjava extends AppCompatActivity {
    private CountDownTimer timer;
    private ImageButton bulbbut = findViewById(R.id.bulbButton);
    private boolean lightswitch = false;
    private boolean armed = false;
    View.OnClickListener armtext = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TextView armme = findViewById(R.id.tVarm);
            if (armed) {
                armme.setText("ARMED");
            } else {
                armme.setText("NOT ARMED");
            }
            armed = !armed;
        }
    };
    private String servip = "";
    View.OnClickListener gographs = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent newmessageIntent = new Intent(Templightifjava.this, TempActivity.class);
            newmessageIntent.putExtra("servip", servip);
            startActivity(newmessageIntent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.temp_graphs);
        Intent intent = getIntent();
        this.servip = intent.getStringExtra("servip");
        int port = intent.getIntExtra("port", 8888);
        Client bulbset = new Client(servip, port, "sql;" + null + ";2;homesmart;'select state from lightdata order BY timelog DESC limit 1'");
        bulbset.run();
        if (bulbset.getReceivedString() == "1") {
            //if its on
            bulbbut.setImageResource(R.drawable.lampon);
            lightswitch = true;
        } else {
            //if its off
            bulbbut.setImageResource(R.drawable.lampoff);
            lightswitch = false;
        }
        Button armbutton = findViewById(R.id.btnArm);
        armbutton.setOnClickListener(armtext);
        Button tempbutton = findViewById(R.id.btnTemp);
        tempbutton.setOnClickListener(gographs);
        godb(this.findViewById(android.R.id.content).getRootView());

////bulbset check if the light is on or off from the database.
//
    }

    public void changebulbtv(View v) {

        if (lightswitch) {
            bulbbut.setImageResource(R.drawable.lampoff);
            lightswitch = false;
            //send to the database that its off now
        } else {
            bulbbut.setImageResource(R.drawable.lampon);
            lightswitch = true;
            //send to the database that its off now
        }
    }

    public void godb(View v) {

        if (!(timer instanceof CountDownTimer)) {
            timer = new CountDownTimer(10000, 1000) {


                @Override
                public void onTick(long millisUntilFinished) {
                    alarm();
                    light();
//                    String command = "command"; // get command from interface/inbuilt
//                    Client javaserv = new Client(ip, port);
//                    String comeback = javaserv.run(command);
//                    //do some fancy stuff to decode comeback.
                }

                @Override
                public void onFinish() {
                    try {
                        timer.start();
                    } catch (Exception e) {
                        Log.e("Error", "Error: " + e.toString());
                    }
                }
            }.start();
        }
    }

    private void alarm() {
        if (armed) {
            try {
                Client rangesensor = new Client(servip, 8888, "sql;" + null + ";2;homesmart;'select timelog from rangedata order BY timelog DESC limit 1'");
                rangesensor.run();
                String datestring = rangesensor.getReceivedString();
                DateFormat dateformat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
                Date date = dateformat.parse(datestring);
                long lastunixTime = (long) date.getTime();
                //seconds*1000 vv
                int threshold = 30000;
                long currunixTime = System.currentTimeMillis();
                if(currunixTime - threshold>lastunixTime){
                    TextView armedalarm = findViewById(R.id.armedalarm);
                    armedalarm.setText("SENSOR FOUND SOMETHING");
                }

            } catch (ParseException e) {
                e.printStackTrace();
            }

        }

    }

    private void light() {
        Client bulbcheck = new Client(servip, 8888,"sql;" + null + ";2;homesmart;'select timelog from lightdata order BY timelog DESC limit 1'");
        bulbcheck.run();
        boolean light = Boolean.parseBoolean(bulbcheck.getReceivedString());
        if(light != lightswitch) {
            changebulbtv(this.findViewById(android.R.id.content).getRootView());
        }

    }
}


