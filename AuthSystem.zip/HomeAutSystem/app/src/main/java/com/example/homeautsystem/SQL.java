package com.example.homeautsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class SQL {
    private static java.sql.Statement stmt;
    private static Connection conn = null;
    //install drivers
    private final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    public String dbName;
    private ArrayList<ArrayList> masterDatabase = null;
    //   private static int[] col = ;

    //global vars
    private String dbUrl;
    //  Database credentials
    private String user;
    private String pass;



    public SQL(String ip, String port, String username, String password, String database) {

        try {
            this.dbName = database;
            //gets the sql class
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        //account data

        this.dbUrl = "jdbc:mysql://" + ip + ":" + port + "/";
        this.user = username;
        this.pass = password;

        try {
            //connects to the database
            this.conn = DriverManager.getConnection(dbUrl, user, pass);



        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
    }

    //use the SQL
    public String select(String command) {

        String result = "false";
        try {
            stmt = (Statement) conn.createStatement();

            result = stmt.executeQuery("use "+dbName+";"+command).toString();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return result;
    }
}

