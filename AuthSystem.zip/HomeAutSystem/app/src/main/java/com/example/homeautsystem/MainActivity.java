package com.example.homeautsystem;

import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.regex.PatternSyntaxException;

public class MainActivity extends AppCompatActivity {

    //login functions and variables
    private String servip = "";
    private String login = "";
    private String password = "";
    private TextView msgTV;
    private int port = 8888;

    //check if ip is of correct form. if the split did not work, throw and exception, if the split worked but there was less or more than 3 dots(delimited) throw an eror
    private void setservip() {
        EditText servtxt = findViewById(R.id.eTservip);
        String ipstring = servtxt.getText().toString();
        try {
            String[] ipcheck = ipstring.split("\\.");
            if (ipcheck.length != 4) {
                this.msgTV.setText("The IP needs to have 4 numbers with dots in between.");
            } else {
                this.servip = servtxt.getText().toString();
            }
        } catch (PatternSyntaxException e) {
            this.msgTV.setText("The IP is typed in wrong");
        }

    }

    private void setlogin() {
        EditText servtxt = findViewById(R.id.eTlogin);
        this.login = servtxt.getText().toString();
    }

    private void setpassword() {
        EditText servtxt = findViewById(R.id.eTpassword);
        this.password = servtxt.getText().toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.gointerfacesbut);
        this.msgTV = findViewById(R.id.messageTv);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                trylogin(v);
            }
        });
    }

    public void trylogin(View v) {
        setservip();
        setlogin();
        setpassword();
        SQL credcheck = new SQL(this.servip, String.valueOf(this.port), "root","", "account");
        String c = credcheck.select("select id from account where user = "+this.login+" and pass"+this.password+" limit 1");

        if(c != null){
            gointerface(v);
        }
    }

    public void gointerface(View v) {
        Intent messageIntent = new Intent(this, Templightifjava.class);
        messageIntent.putExtra("servip", servip);
        messageIntent.putExtra("port", port);
        messageIntent.putExtra("login", login);
        messageIntent.putExtra("password", password);
        startActivity(messageIntent);
    }
}
