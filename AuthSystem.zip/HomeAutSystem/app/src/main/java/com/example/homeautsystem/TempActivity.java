package com.example.homeautsystem;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class TempActivity extends AppCompatActivity {
    private CountDownTimer timer;
    private String servip;
    private int port = 8888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temp_graphs);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
this.servip = getIntent().getStringExtra("servip");
gographs(this.findViewById(android.R.id.content).getRootView());
    }


    public void gographs(View v) {

        if (!(timer instanceof CountDownTimer)) {
            timer = new CountDownTimer(50000, 1000) {


                @Override
                public void onTick(long millisUntilFinished) {
//                    Client data = new Client(servip, port);
//                    String command = "command"; // get command from interface/inbuilt
//                    Client javaserv = new Client(ip, port);
//                    String comeback = javaserv.run(command);
//                    //do some fancy stuff to decode comeback.

// use decoded comeback to affect data passed to DataPoint, as for now its random.

                    GraphView[] graphs = {findViewById(R.id.graph1), findViewById(R.id.graph2), findViewById(R.id.graph3)};
                    for (GraphView graph : graphs) {
                        graph.removeAllSeries();
                        DataPoint[] dp = new DataPoint[100];
                        for (int index = 0; index < 100; index++) {
                            dp[index] = new DataPoint(index, Math.floor(Math.random() * 1000));
                        }

                        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dp);

                        graph.addSeries(series);
                    }
                }

                @Override
                public void onFinish() {
                    try {
timer.start();
                    } catch (Exception e) {
                        Log.e("Error", "Error: " + e.toString());
                    }
                }
            }.start();
        }
    }
}
